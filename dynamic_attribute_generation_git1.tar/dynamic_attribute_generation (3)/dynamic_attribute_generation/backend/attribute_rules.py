# category -> attributes with base priority
from llm_client import ask_tinyllama

# Hardcoded TinyLLaMA prompt - do not modify
TINYLLAMA_PROMPT = """You are an information extraction system.
Do NOT explain.
Do NOT write examples.
Do NOT write paragraphs.
Do NOT invent stories.

Task:
Generate ONE category and EXACTLY 10 attributes.

Output format (exact):

CATEGORY
Electrical Appliance

ATTRIBUTES
- blade size
- power consumption
- speed levels
- mounting type
- noise level
- voltage
- material
- airflow
- energy rating
- warranty"""

CATEGORY_ATTRIBUTES = {
    "container": {
        "Capacity": 10,
        "Material": 9,
        "Weight": 8,
        "Height": 7,
        "Diameter": 7,
        "Lid Type": 6,
        "Insulation": 6,
        "Color": 5,
        "Certification": 5,
        "Usage Type": 4,
        "Shape": 4,
        "Brand": 3,
        "Packaging Type": 2
    },
    "electronics": {
        "Power Rating": 10,
        "Voltage": 9,
        "Current": 8,
        "Dimensions": 7,
        "Weight": 7,
        "Warranty": 6,
        "Model Number": 6,
        "Manufacturer": 5,
        "Energy Efficiency": 5,
        "Connectivity": 4,
        "Operating Temperature": 3
    },
    "service": {
        "Service Type": 10,
        "Service Duration": 9,
        "Location": 8,
        "SLA": 7,
        "Frequency": 6,
        "Manpower Required": 5,
        "Tools Included": 4,
        "Warranty Period": 3,
        "Response Time": 2
    }
}


def adjust_priority_by_item_name(attributes: dict, item_name: str) -> dict:
    item_name = item_name.lower()
    updated_attributes = attributes.copy()

    if "thermal" in item_name:
        if "Insulation" in updated_attributes:
            updated_attributes["Insulation"] += 2

    if "steel" in item_name or "metal" in item_name:
        if "Material" in updated_attributes:
            updated_attributes["Material"] += 1

    if "repair" in item_name:
        if "Service Type" in updated_attributes:
            updated_attributes["Service Type"] += 2

    return updated_attributes


def get_top_attributes(category: str, item_name: str, limit: int = 10) -> list:
    if category not in CATEGORY_ATTRIBUTES:
        return []

    base_attributes = CATEGORY_ATTRIBUTES[category]
    adjusted_attributes = adjust_priority_by_item_name(base_attributes, item_name)

    sorted_attributes = sorted(
        adjusted_attributes.items(),
        key=lambda x: x[1],
        reverse=True
    )

    top_attributes = [attr for attr, _ in sorted_attributes[:limit]]
    return top_attributes


def generate_ai_attributes(item_name: str, limit: int = 10) -> list:
    """
    Generate attributes for unknown items using TinyLLaMA.
    
    This is the FALLBACK flow when:
    - Rule-based category detection fails AND
    - AI-based category detection also fails or returns "unknown"
    
    The function generates practical inventory attributes without assigning a category.
    
    Returns:
        list: List of up to 10 attribute names (strings) or empty list if generation fails
    """
    try:
        # Call TinyLLaMA with hardcoded prompt
        response = ask_tinyllama(TINYLLAMA_PROMPT)
        print(f"[AI Attributes] Raw AI Response for '{item_name}':")
        print(f"  {repr(response)}")
        
        # Parse text-based response format (plain text, no JSON)
        attributes = []
        lines = response.split('\n')
        in_attributes_section = False
        
        for line in lines:
            line = line.strip()
            
            if not line:
                continue
            
            # Detect ATTRIBUTES section
            if line.startswith('ATTRIBUTES:'):
                in_attributes_section = True
                continue
            
            # Parse attribute lines (starting with "-") up to limit
            if in_attributes_section and len(attributes) < limit:
                if line.startswith('-'):
                    # Trim bullet, spaces, and numbering
                    attr = line.lstrip('-').strip()
                    # Remove leading numbers and dots (e.g., "1.", "1)")
                    attr = attr.lstrip('0123456789.)')
                    attr = attr.strip()
                    
                    if attr:
                        attributes.append(attr)
        
        # Clean and deduplicate attributes (keep first 'limit' attributes)
        cleaned_attributes = []
        seen = set()
        
        for attr in attributes[:limit]:
            if isinstance(attr, str):
                normalized = attr.strip()
                if normalized and normalized.lower() not in seen:
                    cleaned_attributes.append(normalized)
                    seen.add(normalized.lower())
        
        # Log parsed output
        print(f"[AI Attributes] Parsed output for '{item_name}': attributes count={len(cleaned_attributes)}")
        print(f"  {cleaned_attributes}")
        
        # Return attributes, logging if count differs from limit
        if len(cleaned_attributes) == limit:
            print(f"[AI Attributes Success] Generated {len(cleaned_attributes)} attributes for '{item_name}'")
        else:
            print(f"[AI Attributes Warning] Expected {limit} attributes, got {len(cleaned_attributes)}")
        
        return cleaned_attributes
    
    except Exception as e:
        print(f"[AI Attributes Error] Item: '{item_name}' - Exception: {type(e).__name__}: {e}")
        return []

# --------------------------------------------
if __name__ == "__main__":
    print(get_top_attributes("container", "thermal steel water bottle"))
    print(get_top_attributes("electronics", "office laptop"))
    print(get_top_attributes("service", "ac repair service"))
