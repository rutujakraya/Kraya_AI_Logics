from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import os

from category_rules import get_category, is_item_predefined, get_category_and_attributes_free_ai
from attribute_rules import get_top_attributes, generate_ai_attributes
from fastapi.middleware.cors import CORSMiddleware


app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ItemRequest(BaseModel):
    item_name: str


class ItemResponse(BaseModel):
    item_name: str
    category: str
    category_source: str
    attributes: list
    attribute_source: str


@app.post("/get-attributes", response_model=ItemResponse)
def get_attributes(request: ItemRequest):
    """
    Get attributes for an item using three-tier approach:
    
    TIER 1: Predefined Items (Rule-Based)
    - Item matches predefined list → use rule-based category + rule-based attributes
    - attribute_source = "rule"
    
    TIER 2: Unrestricted Free AI Mode (for non-predefined items)
    - Item not in predefined list → AI freely chooses category and generates attributes
    - No restriction to known categories
    - attribute_source = "ai_generated" (5+ attributes) or "ai_failed" (< 5 attributes)
    """
    item_name = request.item_name

    # TIER 1: Check if item is predefined (in the known items list)
    if is_item_predefined(item_name):
        # Predefined item: use existing rule-based flow
        category, category_source = get_category(item_name)
        
        if category == "unknown":
            # Shouldn't happen for predefined items, but handle gracefully
            attributes = []
            attribute_source = "ai_failed"
        else:
            # Known category: use rule-based attributes
            attributes = get_top_attributes(category, item_name)
            attribute_source = "rule"
            print(f"[Rule-Based] Item '{item_name}' -> category='{category}', attributes count={len(attributes)}, source='{attribute_source}'")
    else:
        # TIER 2: Free AI Mode for non-predefined items
        # Item is not in the predefined list, so use unrestricted AI
        # to freely choose category and generate attributes
        print(f"[Free AI Mode] Item '{item_name}' not predefined. Using free AI mode for category and attributes.")
        category, attributes, attribute_source = get_category_and_attributes_free_ai(item_name)
        category_source = "ai"
        print(f"[Free AI Mode Result] Item '{item_name}' -> category='{category}', attributes count={len(attributes)}, source='{attribute_source}'")

    return {
        "item_name": item_name,
        "category": category,
        "category_source": category_source,
        "attributes": attributes,
        "attribute_source": attribute_source
    }

# Serve static frontend files
frontend_path = os.path.join(os.path.dirname(__file__), '..', 'frontend')
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")
