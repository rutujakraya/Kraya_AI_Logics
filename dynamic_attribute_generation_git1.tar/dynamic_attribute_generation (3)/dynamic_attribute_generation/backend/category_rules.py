import re
import json
from llm_client import ask_tinyllama

# Hardcoded TinyLLaMA prompt - do not modify
TINYLLAMA_PROMPT = """You are an information extraction system.
Do NOT explain.
Do NOT write examples.
Do NOT write paragraphs.
Do NOT invent stories.

Task:
Generate ONE category and EXACTLY 10 attributes.

Output format (exact):

CATEGORY
Electrical Appliance

ATTRIBUTES
- blade size
- power consumption
- speed levels
- mounting type
- noise level
- voltage
- material
- airflow
- energy rating
- warranty"""

ALLOWED_CATEGORIES = [
    "container",
    "electronics",
    "service",
    "stationery",
    "furniture",
    "hardware",
    "raw_material"
]

# PREDEFINED ITEMS: Items that exist in the known system
# These items use rule-based category + rule-based attributes
# All keywords in KEYWORD_CATEGORY_MAP are considered predefined
PREDEFINED_ITEMS = set()
for keyword in ["bottle", "can", "drum", "laptop", "desktop", "monitor", 
                "chair", "table", "repair", "installation", "maintenance"]:
    PREDEFINED_ITEMS.add(keyword)

# keyword → category mapping
KEYWORD_CATEGORY_MAP = {
    "bottle": "container",
    "can": "container",
    "drum": "container",
    "laptop": "electronics",
    "desktop": "electronics",
    "monitor": "electronics",
    "chair": "furniture",
    "table": "furniture",
    "repair": "service",
    "installation": "service",
    "maintenance": "service"
}

SERVICE_KEYWORDS = [
    "repair",
    "installation",
    "maintenance",
    "service",
    "amc"
]


def normalize_item_name(item_name: str) -> str:
    item_name = item_name.lower()
    item_name = re.sub(r"[^a-z\s]", "", item_name)
    item_name = re.sub(r"\s+", " ", item_name).strip()
    return item_name


def is_item_predefined(item_name: str) -> bool:
    """
    Check if an item exists in the predefined items list.
    
    Returns:
        bool: True if item is predefined (rule-based), False if unknown (needs free AI)
    """
    normalized_name = normalize_item_name(item_name)
    
    # Check if any predefined keyword matches the normalized item name
    for predefined_keyword in PREDEFINED_ITEMS:
        if predefined_keyword in normalized_name:
            return True
    
    return False


def get_category(item_name: str) -> tuple:
    """
    Detect category for an item name.
    
    Returns:
        tuple: (category, source) where:
            - category: str, one of ALLOWED_CATEGORIES or "unknown"
            - source: str, either "rule" or "ai" (indicates detection method)
    
    Flow:
    1. Try rule-based detection first (keyword matching)
    2. If rule-based returns "unknown", fallback to TinyLLaMA
    3. Validate TinyLLaMA response against allowed categories
    4. Return "unknown" if validation fails or LLM call errors
    """
    normalized_name = normalize_item_name(item_name)

    # Step 1: Rule-based category match
    for keyword, category in KEYWORD_CATEGORY_MAP.items():
        if keyword in normalized_name:
            return (category, "rule")

    # Step 2: Rule-based service keyword check
    for keyword in SERVICE_KEYWORDS:
        if keyword in normalized_name:
            return ("service", "rule")

    # Step 3: Rule-based returned "unknown" → fallback to TinyLLaMA
    category, source = _classify_with_tinyllama(item_name)
    return (category, source)


def _classify_with_tinyllama(item_name: str) -> tuple:
    """
    Use TinyLLaMA to classify the item name into a category.
    
    Why extraction and normalization matter:
    - LLM may not follow instructions and returns full explanations
    - We must extract the category from within the response
    - TinyLLaMA may return "Container" instead of "container"
    - We match the first allowed category found in the response
    
    Returns:
        tuple: (category, source) where:
            - category: valid category from ALLOWED_CATEGORIES, or "unknown"
            - source: always "ai" to indicate LLM classification
    """
    try:
        # Call TinyLLaMA with hardcoded prompt
        response = ask_tinyllama(TINYLLAMA_PROMPT)
        print(f"[TinyLLaMA Response] Item: '{item_name}' -> Raw Response: '{response}'")
        
        # Strategy: Search for any allowed category in the response (case-insensitive)
        # This handles cases where the LLM returns an explanation instead of just the category
        response_lower = response.lower()
        
        for allowed_category in ALLOWED_CATEGORIES:
            if allowed_category in response_lower:
                print(f"[TinyLLaMA Success] '{item_name}' classified as '{allowed_category}' (found in response)")
                return (allowed_category, "ai")
        
        # If no allowed category found in response
        print(f"[TinyLLaMA Failed] '{item_name}' -> No allowed category found in response: '{response}'")
        return ("unknown", "ai")
    
    except Exception as e:
        # LLM call failed (network, timeout, Ollama unavailable, etc.)
        print(f"[TinyLLaMA Error] Item: '{item_name}' - Exception: {type(e).__name__}: {e}")
        return ("unknown", "ai")

def get_category_and_attributes_free_ai(item_name: str) -> tuple:
    """
    FREE AI MODE: Generate both category and attributes for unknown items.
    
    This function is called when an item is NOT in the predefined items list.
    AI is unrestricted and can:
    - Choose any category freely (not limited to ALLOWED_CATEGORIES)
    - Generate exactly 10 relevant attributes specific to that item
    
    Uses strict text-based prompt format (not JSON) to enforce compliance.
    Attributes must be 1-2 words each with no explanations.
    
    VALIDATION LAYER:
    - If fewer than 5 attributes extracted: mark as failed (ai_failed)
    - If 5 or more attributes: mark as generated (ai_generated)
    
    This enables the system to handle completely new/custom items.
    
    Returns:
        tuple: (category, attributes, attribute_source) where:
            - category: str, AI-inferred category or "Custom Item" on failure
            - attributes: list of str, AI-generated attributes or [] on failure
            - attribute_source: str, either "ai_generated" or "ai_failed"
    """
    try:
        # Call TinyLLaMA with hardcoded prompt
        response = ask_tinyllama(TINYLLAMA_PROMPT)
        print(f"[Free AI Mode] Raw AI Response for '{item_name}':")
        print(f"  {repr(response)}")
        
        # Parse text-based response format (plain text, no JSON)
        category = None
        attributes = []
        
        lines = response.split('\n')
        in_attributes_section = False
        
        for line in lines:
            line = line.strip()
            
            if not line:
                continue
            
            # Extract CATEGORY from line starting with "CATEGORY:"
            if line.startswith('CATEGORY:'):
                category = line.replace('CATEGORY:', '').strip()
                continue
            
            # Detect ATTRIBUTES section
            if line.startswith('ATTRIBUTES:'):
                in_attributes_section = True
                continue
            
            # Parse attribute lines (starting with "-")
            if in_attributes_section and len(attributes) < 10:
                if line.startswith('-'):
                    # Trim bullet, spaces, and numbering
                    attr = line.lstrip('-').strip()
                    # Remove leading numbers and dots (e.g., "1.", "1)")
                    attr = attr.lstrip('0123456789.)')
                    attr = attr.strip()
                    
                    if attr:
                        attributes.append(attr)
        
        # Validate category
        if not category:
            print(f"[Free AI Mode Failed] No category found in response")
            print(f"[Free AI Mode Fallback] Returning 'Custom Item' with empty attributes")
            return ("Custom Item", [], "ai_failed")
        
        # Clean and deduplicate attributes (keep first 10)
        cleaned_attributes = []
        seen = set()
        
        for attr in attributes[:10]:  # Stop after 10 attributes
            if isinstance(attr, str):
                normalized = attr.strip()
                if normalized and normalized.lower() not in seen:
                    cleaned_attributes.append(normalized)
                    seen.add(normalized.lower())
        
        # Log parsed output
        parsed_output = {
            "category": category,
            "attributes": cleaned_attributes
        }
        print(f"[Free AI Mode] Parsed output for '{item_name}': {parsed_output}")
        
        # VALIDATION LAYER: Check attribute count for fallback
        if len(cleaned_attributes) < 5:
            # Fewer than 5 attributes: mark as failed
            print(f"[Free AI Mode Validation Failed] Expected at least 5 attributes, got {len(cleaned_attributes)}")
            print(f"[Free AI Mode Fallback] Setting category to 'Custom Item' and attributes to []")
            return ("Custom Item", [], "ai_failed")
        elif len(cleaned_attributes) < 10:
            # 5-9 attributes: mark as generated (partial success)
            print(f"[Free AI Mode Validation Warning] Expected 10 attributes, got {len(cleaned_attributes)} (using anyway)")
            print(f"[Free AI Mode Success - Partial] '{item_name}' -> category='{category}', attributes count={len(cleaned_attributes)}")
            return (category, cleaned_attributes, "ai_generated")
        else:
            # 10 or more attributes: full success
            print(f"[Free AI Mode Success] '{item_name}' -> category='{category}', attributes count=10")
            return (category, cleaned_attributes[:10], "ai_generated")
    
    except Exception as e:
        print(f"[Free AI Mode Error] Item: '{item_name}' - Exception: {type(e).__name__}: {e}")
        print(f"[Free AI Mode Fallback] Returning 'Custom Item' with empty attributes")
        return ("Custom Item", [], "ai_failed")
# ----------------------------------------------
if __name__ == "__main__":
    test_items = [
        "Steel Water Bottle 1L",
        "Office Chair",
        "Laptop Repair Service",
        "Wooden Table",
        "Thermal Flask"
    ]

    for item in test_items:
        print(item, "->", get_category(item))
