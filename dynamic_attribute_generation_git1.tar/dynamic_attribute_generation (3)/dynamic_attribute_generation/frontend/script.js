const API_BASE_URL = 'http://127.0.0.1:8000';

// DOM Elements
const itemNameInput = document.getElementById('itemName');
const fetchBtn = document.getElementById('fetchBtn');
const errorMessage = document.getElementById('errorMessage');
const resultSection = document.getElementById('resultSection');
const categoryValue = document.getElementById('categoryValue');
const attributesList = document.getElementById('attributesList');
const addAttributeBtn = document.getElementById('addAttributeBtn');

// State
let currentAttributes = [];
let customAttributeCount = 0;

// Event Listeners
fetchBtn.addEventListener('click', handleFetchAttributes);
itemNameInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleFetchAttributes();
});
addAttributeBtn.addEventListener('click', handleAddCustomAttribute);

// Fetch attributes from backend
async function handleFetchAttributes() {
    const itemName = itemNameInput.value.trim();

    // Clear previous errors
    clearError();

    if (!itemName) {
        showError('Please enter an item name');
        return;
    }

    // Disable button and show loading state
    fetchBtn.disabled = true;
    const originalText = fetchBtn.textContent;
    fetchBtn.textContent = 'Loading...';

    try {
        const response = await fetch(`${API_BASE_URL}/get-attributes`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ item_name: itemName }),
        });

        if (!response.ok) {
            throw new Error(`Server error: ${response.status}`);
        }

        const data = await response.json();

        // Update category
        categoryValue.textContent = data.category || 'Unknown';

        // Initialize attributes from backend
        currentAttributes = data.attributes.map((attr, index) => ({
            id: `attr-${index}`,
            name: attr,
            value: '',
            isCustom: false,
        }));

        customAttributeCount = 0; // Reset custom count

        // Render attributes
        renderAttributes();

        // Show result section
        resultSection.classList.remove('hidden');
    } catch (error) {
        console.error('Error fetching attributes:', error);
        showError(
            error.message.includes('fetch')
                ? 'Unable to connect to backend. Make sure the server is running at http://127.0.0.1:8000'
                : error.message
        );
    } finally {
        fetchBtn.disabled = false;
        fetchBtn.textContent = originalText;
    }
}

// Render attributes list
function renderAttributes() {
    attributesList.innerHTML = '';

    currentAttributes.forEach((attr) => {
        const attributeItem = document.createElement('div');
        attributeItem.className = 'attribute-item';
        attributeItem.id = attr.id;

        attributeItem.innerHTML = `
            <div class="attribute-header">
                <label class="attribute-label">
                    ${escapeHtml(attr.name)}
                    ${attr.isCustom ? '<span class="custom-badge">Custom</span>' : ''}
                </label>
                <button class="btn-remove" aria-label="Remove attribute" data-id="${attr.id}">
                    ❌
                </button>
            </div>
            <input 
                type="text" 
                class="attribute-input ${attr.isCustom ? 'custom' : ''}"
                placeholder="Enter ${escapeHtml(attr.name)}"
                value="${escapeHtml(attr.value)}"
                data-id="${attr.id}"
            >
        `;

        attributesList.appendChild(attributeItem);

        // Add event listeners
        const removeBtn = attributeItem.querySelector('.btn-remove');
        const input = attributeItem.querySelector('.attribute-input');

        removeBtn.addEventListener('click', () => handleRemoveAttribute(attr.id));
        input.addEventListener('input', (e) => handleAttributeValueChange(attr.id, e.target.value));
    });
}

// Handle attribute value change
function handleAttributeValueChange(attrId, newValue) {
    const attr = currentAttributes.find((a) => a.id === attrId);
    if (attr) {
        attr.value = newValue;
    }
}

// Handle remove attribute
function handleRemoveAttribute(attrId) {
    currentAttributes = currentAttributes.filter((a) => a.id !== attrId);
    renderAttributes();
}

// Handle add custom attribute
function handleAddCustomAttribute() {
    const customAttrName = prompt('Enter custom attribute name:');

    if (!customAttrName || customAttrName.trim() === '') {
        return; // User cancelled or empty
    }

    const trimmedName = customAttrName.trim();

    // Check for duplicates
    if (currentAttributes.some((a) => a.name.toLowerCase() === trimmedName.toLowerCase())) {
        showError('This attribute already exists');
        return;
    }

    customAttributeCount++;
    const newAttr = {
        id: `custom-${customAttributeCount}`,
        name: trimmedName,
        value: '',
        isCustom: true,
    };

    currentAttributes.push(newAttr);
    renderAttributes();

    // Focus on the new input
    setTimeout(() => {
        const newInput = document.querySelector(`[data-id="${newAttr.id}"]`);
        if (newInput) newInput.focus();
    }, 0);
}

// Error handling
function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.add('show');
}

function clearError() {
    errorMessage.textContent = '';
    errorMessage.classList.remove('show');
}

// Utility function to escape HTML
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;',
    };
    return text.replace(/[&<>"']/g, (m) => map[m]);
}
